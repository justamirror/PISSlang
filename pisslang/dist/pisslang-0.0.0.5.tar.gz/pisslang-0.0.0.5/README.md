# PISSlang
Aww, piss
## What is this vile thing?
PISSlang is a joke programming language
## Docs?
I just got this up jesus