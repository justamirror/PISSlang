import cool
def test():
  print("hilol")