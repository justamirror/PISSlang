def test2():
  print("coolio")